class AddImageTagToBooks < ActiveRecord::Migration[5.2]
  def change
    add_column :books, :image_tag, :string
  end
end
