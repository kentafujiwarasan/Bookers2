class RemoveImageTagFromBooks < ActiveRecord::Migration[5.2]
  def change
    remove_column :books, :image_tag, :string
  end
end
