# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '67ce84bdca0997ffa5915ec5b1fe44dc39f97be3a227789824aa7cccfea2f462d7ebc83ff54354087b39bd737b6d1bd8df3b06ce302978be9d0753b6a8c96269'